/** Automatically generated file. DO NOT MODIFY */
package com.ethangrimes.golfscorekeeper;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}